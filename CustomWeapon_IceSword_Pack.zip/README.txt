CustomWeapon - Ice Sword (Minecraft 1.21.11, pack_format 75)

Model id (item_model component):  customweapon:ice_sword
Files:
  assets/customweapon/items/ice_sword.json          - item definition
  assets/customweapon/models/item/ice_sword.json    - 3D model
  assets/customweapon/textures/item/ice_sword.png   - 64x64 texture

Test in game:
  /give @p minecraft:diamond_sword[item_model="customweapon:ice_sword"]
